import { NextResponse } from "next/server"
import { createCanvas } from "canvas"

export async function GET(request) {
  const { searchParams } = new URL(request.url)
  const cash = searchParams.get("cash") || "2000"
  const day = searchParams.get("day") || "1"
  const location = searchParams.get("location") || "bronx"

  // Create a canvas for the frame image
  const canvas = createCanvas(1200, 630)
  const ctx = canvas.getContext("2d")

  // Background
  ctx.fillStyle = "#111827"
  ctx.fillRect(0, 0, 1200, 630)

  // Add gradient overlay
  const gradient = ctx.createLinearGradient(0, 0, 0, 630)
  gradient.addColorStop(0, "rgba(30, 41, 59, 0.8)")
  gradient.addColorStop(1, "rgba(15, 23, 42, 0.9)")
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, 1200, 630)

  // Add a new parameter to check if we're showing the splash screen
  const showSplash = searchParams.get("splash") === "true"

  // Update the image generation to show different content for splash screen
  // Add this after the background setup but before the title

  if (showSplash) {
    // Title
    ctx.font = "bold 70px sans-serif"
    ctx.fillStyle = "#ffffff"
    ctx.textAlign = "center"
    ctx.fillText("DOPE WARS", 600, 150)

    // Subtitle
    ctx.font = "30px sans-serif"
    ctx.fillStyle = "#9ca3af"
    ctx.fillText("The Classic Drug Dealing Simulation", 600, 210)

    // Instructions
    ctx.font = "bold 36px sans-serif"
    ctx.fillStyle = "#ffffff"
    ctx.textAlign = "center"
    ctx.fillText("HOW TO PLAY", 600, 290)

    ctx.font = "24px sans-serif"
    ctx.fillStyle = "#d1d5db"
    ctx.fillText("1. Buy low, sell high across different neighborhoods", 600, 350)
    ctx.fillText("2. Travel between areas to find the best prices", 600, 400)
    ctx.fillText("3. Manage your money and watch out for events", 600, 450)

    // Call to action
    ctx.font = "bold 32px sans-serif"
    ctx.fillStyle = "#ffffff"
    ctx.fillText("Tap to start hustling", 600, 550)

    // Convert canvas to buffer
    const buffer = canvas.toBuffer("image/png")

    return new NextResponse(buffer, {
      headers: {
        "Content-Type": "image/png",
        "Cache-Control": "max-age=10",
      },
    })
  }

  // Title
  ctx.font = "bold 60px sans-serif"
  ctx.fillStyle = "#ffffff"
  ctx.textAlign = "center"
  ctx.fillText("DOPE WARS", 600, 150)

  // Location name
  let locationName = "The Bronx"
  switch (location) {
    case "brooklyn":
      locationName = "Brooklyn"
      break
    case "manhattan":
      locationName = "Manhattan"
      break
    case "queens":
      locationName = "Queens"
      break
    case "statenIsland":
      locationName = "Staten Island"
      break
  }

  ctx.font = "40px sans-serif"
  ctx.fillStyle = "#9ca3af"
  ctx.fillText(locationName, 600, 220)

  // Stats
  ctx.font = "bold 36px sans-serif"
  ctx.fillStyle = "#10b981"
  ctx.textAlign = "center"
  ctx.fillText(`$${Number.parseInt(cash).toLocaleString()}`, 600, 320)

  ctx.font = "28px sans-serif"
  ctx.fillStyle = "#9ca3af"
  ctx.fillText(`Day ${day}/30`, 600, 380)

  // Call to action
  ctx.font = "bold 32px sans-serif"
  ctx.fillStyle = "#ffffff"
  ctx.fillText("Tap to continue your hustle", 600, 500)

  // Convert canvas to buffer
  const buffer = canvas.toBuffer("image/png")

  return new NextResponse(buffer, {
    headers: {
      "Content-Type": "image/png",
      "Cache-Control": "max-age=10",
    },
  })
}

