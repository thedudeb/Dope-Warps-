"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Package } from "lucide-react"

interface InventoryItem {
  id: string
  name: string
  quantity: number
  boughtAt: number
}

interface MarketItem {
  id: string
  name: string
  price: number
}

interface InventoryViewProps {
  inventory: InventoryItem[]
  market: MarketItem[]
  onSell: (itemId: string) => void
}

export default function InventoryView({ inventory, market, onSell }: InventoryViewProps) {
  if (inventory.length === 0) {
    return (
      <Card className="border shadow-sm">
        <CardHeader className="py-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Package className="h-5 w-5 text-primary" />
            Your Inventory
          </CardTitle>
        </CardHeader>
        <CardContent className="pb-4">
          <div className="text-center py-8 text-muted-foreground">
            Your inventory is empty. Buy items from the market.
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border shadow-sm">
      <CardHeader className="py-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Package className="h-5 w-5 text-primary" />
          Your Inventory
        </CardTitle>
      </CardHeader>
      <CardContent className="pb-4">
        <div className="grid gap-2">
          {inventory.map((item) => {
            const marketItem = market.find((m) => m.id === item.id)
            const currentPrice = marketItem?.price || 0
            const profitPerItem = currentPrice - item.boughtAt
            const profitClass =
              profitPerItem > 0 ? "text-green-500" : profitPerItem < 0 ? "text-red-500" : "text-gray-500"

            return (
              <div
                key={item.id}
                className="grid grid-cols-4 items-center p-2 rounded-md bg-secondary/50 hover:bg-secondary/70 transition-colors"
              >
                <div className="font-medium">{item.name}</div>
                <div className="text-center">x{item.quantity}</div>
                <div className="text-right">
                  <div className="flex flex-col">
                    <span className="text-sm font-mono">Bought: ${item.boughtAt}</span>
                    {marketItem && (
                      <span className={`text-xs ${profitClass}`}>
                        Now: ${currentPrice} ({profitPerItem > 0 ? "+" : ""}${profitPerItem})
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex justify-end">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onSell(item.id)}
                    disabled={!marketItem}
                    title={
                      !marketItem
                        ? "Can't sell here"
                        : `Sell ${item.name} for $${currentPrice} (${
                            profitPerItem > 0 ? "+" : ""
                          }$${profitPerItem} profit)`
                    }
                  >
                    Sell
                  </Button>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}

