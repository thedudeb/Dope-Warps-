"use client"

import { useState, useEffect, useRef } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { MapPin, Wallet, Building2, AlertTriangle, Trophy } from "lucide-react"
import LocationSelector from "@/components/location-selector"
import MarketView from "@/components/market-view"
import InventoryView from "@/components/inventory-view"
import StoreView from "@/components/store-view"
import EventNotification from "@/components/event-notification"
import EndGameScreen from "@/components/end-game-screen"
import { useGameState } from "@/lib/game-state"
import LeaderboardView from "@/components/leaderboard-view"
import { Button } from "@/components/ui/button"
import SplashScreen from "@/components/splash-screen"

export default function GameContainer() {
  const searchParams = useSearchParams()
  const [activeTab, setActiveTab] = useState("market")
  const {
    gameState,
    initGame,
    travel,
    buyItem,
    sellItem,
    handleRandomEvent,
    deposit,
    withdraw,
    updateHealth,
    takeLoan,
    payDebt,
  } = useGameState()

  // Replace the single event state with an array of events
  const [events, setEvents] = useState([])
  const [view, setView] = useState("game") // "game", "leaderboard"
  const [showSplash, setShowSplash] = useState(true)

  // Use a ref to track if we've already set up frame metadata
  const frameMetadataRef = useRef(false)

  // Use a ref to track the previous gameState to prevent unnecessary updates
  const prevGameStateRef = useRef(null)

  // Get FID and username from search params
  const fid = searchParams.get("fid")
  const username = searchParams.get("username")

  // Initialize game only once
  useEffect(() => {
    console.log("Initializing game...")
    const fid = searchParams.get("fid") || "default"
    initGame(fid)
  }, []) // Remove dependencies to ensure this only runs once

  // Handle frame metadata in a separate effect with proper dependency tracking
  useEffect(() => {
    // Only proceed if gameState exists and has changed
    if (!gameState) return

    // Skip if we've already set up metadata for this state
    // This is a simple comparison - in a real app you might want to do a deeper comparison
    if (
      prevGameStateRef.current &&
      prevGameStateRef.current.cash === gameState.cash &&
      prevGameStateRef.current.day === gameState.day &&
      prevGameStateRef.current.currentLocation?.id === gameState.currentLocation.id
    ) {
      return
    }

    // Update our ref with the current state
    prevGameStateRef.current = {
      cash: gameState.cash,
      day: gameState.day,
      currentLocation: { id: gameState.currentLocation.id },
    }

    // Set up frame metadata
    try {
      // Create a container for our metadata if it doesn't exist
      let container = document.getElementById("frame-metadata-container")
      if (!container) {
        container = document.createElement("div")
        container.id = "frame-metadata-container"
        document.head.appendChild(container)
      }

      // Clear existing metadata
      container.innerHTML = ""

      // Helper function to create meta tags
      const createMetaTag = (property, content) => {
        const meta = document.createElement("meta")
        meta.setAttribute("property", property)
        meta.setAttribute("content", content)
        container.appendChild(meta)
      }

      // Add frame metadata
      createMetaTag("fc:frame", "vNext")

      // Add frame image
      const imageUrl = showSplash
        ? `${window.location.origin}/api/frame-image?splash=true`
        : `${window.location.origin}/api/frame-image?cash=${gameState.cash}&day=${gameState.day}&location=${gameState.currentLocation.id}`

      createMetaTag("fc:frame:image", imageUrl)

      // Add buttons
      const addButton = (index, text, targetUrl) => {
        createMetaTag(`fc:frame:button:${index}`, text)
        createMetaTag(`fc:frame:button:${index}:action`, "post")
        createMetaTag(`fc:frame:button:${index}:target`, targetUrl)
      }

      // Add buttons based on whether we're showing splash or game
      if (showSplash) {
        // Just one button for the splash screen
        addButton(
          1,
          "Start Game",
          `${window.location.origin}/api/frame-action?action=market&location=${gameState.currentLocation.id}`,
        )
      } else {
        // Regular game buttons
        addButton(
          1,
          "Market",
          `${window.location.origin}/api/frame-action?action=market&location=${gameState.currentLocation.id}`,
        )

        addButton(
          2,
          "Inventory",
          `${window.location.origin}/api/frame-action?action=inventory&location=${gameState.currentLocation.id}`,
        )

        addButton(
          3,
          "Travel",
          `${window.location.origin}/api/frame-action?action=travel&location=${gameState.currentLocation.id}`,
        )

        // Add end game button if on last day
        if (gameState.day >= 29) {
          addButton(4, "End Game", `${window.location.origin}/api/frame-action?action=endgame`)
        }
      }

      // Mark that we've set up frame metadata
      frameMetadataRef.current = true
    } catch (error) {
      console.error("Error setting up frame metadata:", error)
    }
  }, [gameState?.cash, gameState?.day, gameState?.currentLocation?.id, showSplash])

  // Handle event acceptance
  const handleEventAccept = (eventId) => {
    // Remove the event from the list
    setEvents((prev) => prev.filter((e) => e.id !== eventId))

    // You could add additional effects here based on event type
    // For example, give bonus rewards for accepting positive events
  }

  // Handle event dismissal
  const handleEventDismiss = (eventId) => {
    // Simply remove the event from the list
    setEvents((prev) => prev.filter((e) => e.id !== eventId))
  }

  // Handle travel with potential random events
  const handleTravel = (locationId) => {
    // Don't do anything if we're already at this location or if gameState doesn't exist
    if (!gameState || gameState.currentLocation.id === locationId) return

    // Handle random event - FIX: Always check for random events when traveling
    const eventResult = handleRandomEvent()
    if (eventResult) {
      // Add a unique ID to the event for management
      const eventWithId = { ...eventResult, id: Date.now() }
      setEvents((prev) => [...prev, eventWithId])
    }

    // Travel to new location
    travel(locationId)
  }

  // Update the handleNewGame function
  const handleNewGame = () => {
    initGame("new-game")
    setEvents([]) // Clear any existing events
    setView("game") // Return to game view
  }

  // Add this function to handle viewing the leaderboard
  const handleViewLeaderboard = () => {
    setView("leaderboard")
  }

  // Add this function to return to the game
  const handleBackToGame = () => {
    setView("game")
  }

  // Add this function to handle continuing from the splash screen
  const handleContinueFromSplash = () => {
    setShowSplash(false)
  }

  // If game state is not initialized yet, show loading
  if (!gameState) {
    return (
      <div className="min-h-[800px] w-full max-w-5xl mx-auto p-4 flex items-center justify-center">
        <Card className="border-2 shadow-lg p-8">
          <CardContent className="flex flex-col items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4"></div>
            <p>Loading game...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Show end game screen if day is greater than 30 (CHANGED FROM 60)
  if (gameState.day > 30) {
    return (
      <div className="min-h-[800px] w-full max-w-5xl mx-auto p-4 flex items-center justify-center">
        {view === "game" ? (
          <EndGameScreen
            gameState={gameState}
            onNewGame={handleNewGame}
            onViewLeaderboard={handleViewLeaderboard}
            fid={fid}
            username={username}
          />
        ) : (
          <LeaderboardView onBack={handleBackToGame} />
        )}
      </div>
    )
  }

  // Show splash screen if it's enabled
  if (showSplash) {
    return (
      <div className="min-h-[800px] w-full max-w-5xl mx-auto p-4 flex items-center justify-center">
        <SplashScreen onContinue={handleContinueFromSplash} />
      </div>
    )
  }

  return (
    <div className="min-h-[800px] w-full max-w-5xl mx-auto p-4">
      <Card className="border-2 shadow-lg h-full">
        <CardContent className="p-6">
          {/* Stats Bar */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between bg-secondary/50 p-3 rounded-lg">
                <span className="text-sm font-mono">Day: {gameState.day}/30</span>
                <span className="text-yellow-500 font-mono">{Math.floor((gameState.day / 30) * 100)}%</span>
              </div>
              <div className="flex items-center justify-between bg-secondary/50 p-3 rounded-lg">
                <Wallet className="h-4 w-4 text-green-500" />
                <span className="font-mono text-green-500">${gameState.cash.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between bg-secondary/50 p-3 rounded-lg">
                <Building2 className="h-4 w-4 text-blue-500" />
                <span className="font-mono text-blue-500">${gameState.bank.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between bg-secondary/50 p-3 rounded-lg">
                <AlertTriangle className="h-4 w-4 text-red-500" />
                <span className="font-mono text-red-500">${gameState.debt.toLocaleString()}</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between bg-secondary/50 p-3 rounded-lg">
                <MapPin className="h-4 w-4" />
                <Badge variant="outline">{gameState.currentLocation.name}</Badge>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span>Health</span>
                  <span>{gameState.health}%</span>
                </div>
                <Progress
                  value={gameState.health}
                  className="h-2"
                  indicatorClassName={
                    gameState.health > 70 ? "bg-green-500" : gameState.health > 30 ? "bg-yellow-500" : "bg-red-500"
                  }
                />
              </div>
              <div className="flex items-center justify-between bg-secondary/50 p-3 rounded-lg">
                <span>Trenchcoat Space:</span>
                <span>
                  {gameState.inventory.reduce((acc, item) => acc + item.quantity, 0)}/{gameState.maxInventory}
                </span>
              </div>
            </div>
          </div>

          {/* Location Selector */}
          <LocationSelector
            locations={gameState.locations}
            currentLocationId={gameState.currentLocation.id}
            onTravel={handleTravel}
            className="mb-6"
          />

          {/* Main Content */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="market">Market</TabsTrigger>
              <TabsTrigger value="inventory">Inventory</TabsTrigger>
              <TabsTrigger value="store">Store</TabsTrigger>
            </TabsList>
            <TabsContent value="market" className="mt-4">
              <MarketView
                market={gameState.currentLocation.market}
                cash={gameState.cash}
                inventory={gameState.inventory}
                maxInventory={gameState.maxInventory}
                onBuy={buyItem}
                onSell={sellItem}
              />
            </TabsContent>
            <TabsContent value="inventory" className="mt-4">
              <InventoryView
                inventory={gameState.inventory}
                market={gameState.currentLocation.market}
                onSell={sellItem}
              />
            </TabsContent>
            <TabsContent value="store" className="mt-4">
              <StoreView
                cash={gameState.cash}
                health={gameState.health}
                onBuyHealth={updateHealth}
                onBuyItem={() => {}}
                deposit={deposit}
                withdraw={withdraw}
                takeLoan={takeLoan}
                payDebt={payDebt}
              />
            </TabsContent>
          </Tabs>
          <div className="flex justify-end mt-2">
            <Button variant="outline" size="sm" onClick={handleViewLeaderboard} className="flex items-center gap-1">
              <Trophy className="h-4 w-4" />
              Leaderboard
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Event Notifications */}
      <div className="fixed bottom-4 right-4 flex flex-col gap-2 max-w-sm z-50">
        {events.map((event) => (
          <EventNotification
            key={event.id}
            event={event}
            onAccept={() => handleEventAccept(event.id)}
            onDismiss={() => handleEventDismiss(event.id)}
          />
        ))}
      </div>
    </div>
  )
}

