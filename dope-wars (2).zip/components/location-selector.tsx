"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { MapPin, ChevronDown } from "lucide-react"
import { cn } from "@/lib/utils"

interface Location {
  id: string
  name: string
  priceModifier?: number
  market?: any[]
}

interface LocationSelectorProps {
  locations: Location[]
  currentLocationId: string
  onTravel: (locationId: string) => void
  className?: string
}

export default function LocationSelector({ locations, currentLocationId, onTravel, className }: LocationSelectorProps) {
  const [open, setOpen] = useState(false)

  const currentLocation = locations.find((loc) => loc.id === currentLocationId) || locations[0]

  return (
    <Card className={cn("border shadow-sm", className)}>
      <CardHeader className="py-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <MapPin className="h-5 w-5 text-primary" />
          Current Location
        </CardTitle>
      </CardHeader>
      <CardContent className="pb-4">
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="w-full justify-between font-normal" disabled={locations.length <= 1}>
              {currentLocation.name}
              <ChevronDown className="h-4 w-4 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="p-0 w-full" align="start">
            <div className="grid divide-y">
              {locations.map((location) => (
                <Button
                  key={location.id}
                  variant="ghost"
                  className={cn(
                    "justify-start font-normal rounded-none h-10",
                    location.id === currentLocationId && "bg-secondary",
                  )}
                  disabled={location.id === currentLocationId}
                  onClick={() => {
                    onTravel(location.id)
                    setOpen(false)
                  }}
                >
                  {location.name}
                </Button>
              ))}
            </div>
          </PopoverContent>
        </Popover>
      </CardContent>
    </Card>
  )
}

