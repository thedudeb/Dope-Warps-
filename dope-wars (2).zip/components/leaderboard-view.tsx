"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, ArrowLeft, User, Coins, Calendar } from "lucide-react"
import { getLeaderboard } from "@/lib/leaderboard"

interface LeaderboardEntry {
  fid: string
  username: string
  score: number
  timestamp: string
  stats: {
    cash: number
    bank: number
    debt: number
    inventory: number
    days: number
    rank: string
  }
}

interface LeaderboardViewProps {
  onBack: () => void
}

export default function LeaderboardView({ onBack }: LeaderboardViewProps) {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchLeaderboard() {
      try {
        setLoading(true)
        const data = await getLeaderboard()
        setLeaderboard(data)
      } catch (err) {
        console.error("Error fetching leaderboard:", err)
        setError("Failed to load leaderboard data")
      } finally {
        setLoading(false)
      }
    }

    fetchLeaderboard()
  }, [])

  if (loading) {
    return (
      <Card className="border-2 shadow-lg w-full max-w-2xl mx-auto">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4"></div>
          <p>Loading leaderboard...</p>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className="border-2 shadow-lg w-full max-w-2xl mx-auto">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <p className="text-red-500 mb-4">{error}</p>
          <Button onClick={onBack}>Go Back</Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-2 shadow-lg w-full max-w-2xl mx-auto">
      <CardHeader className="text-center border-b pb-6">
        <CardTitle className="text-3xl flex justify-center items-center gap-2">
          <Trophy className="h-8 w-8 text-yellow-500" />
          Leaderboard
        </CardTitle>
      </CardHeader>

      <CardContent className="pt-6">
        <Tabs defaultValue="all">
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="all">All Time</TabsTrigger>
            <TabsTrigger value="today">Today</TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            {leaderboard.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No scores recorded yet. Be the first to make the leaderboard!
              </div>
            ) : (
              <div className="space-y-4">
                {leaderboard.map((entry, index) => (
                  <LeaderboardEntry key={index} entry={entry} rank={index + 1} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="today">
            {/* Filter for today's entries */}
            {leaderboard.filter((entry) => {
              const today = new Date().toISOString().split("T")[0]
              const entryDate = new Date(entry.timestamp).toISOString().split("T")[0]
              return today === entryDate
            }).length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No scores recorded today. Be the first to make today's leaderboard!
              </div>
            ) : (
              <div className="space-y-4">
                {leaderboard
                  .filter((entry) => {
                    const today = new Date().toISOString().split("T")[0]
                    const entryDate = new Date(entry.timestamp).toISOString().split("T")[0]
                    return today === entryDate
                  })
                  .map((entry, index) => (
                    <LeaderboardEntry key={index} entry={entry} rank={index + 1} />
                  ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>

      <CardFooter className="border-t pt-6">
        <Button onClick={onBack} className="w-full flex items-center justify-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          Back to Game
        </Button>
      </CardFooter>
    </Card>
  )
}

function LeaderboardEntry({ entry, rank }: { entry: LeaderboardEntry; rank: number }) {
  const [expanded, setExpanded] = useState(false)

  return (
    <Card
      className="border shadow-sm overflow-hidden transition-all duration-300"
      style={{ maxHeight: expanded ? "500px" : "100px" }}
    >
      <div
        className="p-4 flex items-center cursor-pointer hover:bg-secondary/50"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-bold mr-3">
          {rank}
        </div>

        <div className="flex-1">
          <div className="flex items-center">
            <User className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="font-medium">{entry.username || `User ${entry.fid.substring(0, 6)}`}</span>
          </div>
          <div className="text-sm text-muted-foreground">{entry.stats.rank}</div>
        </div>

        <div className="text-right">
          <div className="font-bold text-lg">{entry.score.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">{new Date(entry.timestamp).toLocaleDateString()}</div>
        </div>
      </div>

      {expanded && (
        <div className="px-4 pb-4 pt-2 border-t bg-secondary/10">
          <h4 className="font-medium mb-2">Stats</h4>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center">
              <Coins className="h-4 w-4 mr-2 text-green-500" />
              <span className="text-sm">Cash: ${entry.stats.cash.toLocaleString()}</span>
            </div>
            <div className="flex items-center">
              <Coins className="h-4 w-4 mr-2 text-blue-500" />
              <span className="text-sm">Bank: ${entry.stats.bank.toLocaleString()}</span>
            </div>
            <div className="flex items-center">
              <Coins className="h-4 w-4 mr-2 text-red-500" />
              <span className="text-sm">Debt: ${entry.stats.debt.toLocaleString()}</span>
            </div>
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-2" />
              <span className="text-sm">Days: {entry.stats.days}/30</span>
            </div>
          </div>
        </div>
      )}
    </Card>
  )
}

