"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight, Info, HelpCircle, Coins, MapPin, ShoppingBag, User } from "lucide-react"

interface SplashScreenProps {
  onContinue: () => void
}

export default function SplashScreen({ onContinue }: SplashScreenProps) {
  return (
    <Card className="border-2 shadow-lg w-full max-w-2xl mx-auto">
      <CardHeader className="text-center border-b pb-6">
        <CardTitle className="text-3xl">DOPE WARS</CardTitle>
        <p className="text-muted-foreground">The classic drug dealing simulation</p>
      </CardHeader>

      <CardContent className="pt-6">
        <Tabs defaultValue="howto">
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="howto">How To Play</TabsTrigger>
            <TabsTrigger value="about">About</TabsTrigger>
          </TabsList>

          <TabsContent value="howto">
            <div className="space-y-4">
              <div className="bg-secondary/50 p-4 rounded-lg">
                <h3 className="font-medium flex items-center gap-2 mb-2">
                  <Coins className="h-5 w-5 text-green-500" />
                  Buy Low, Sell High
                </h3>
                <p className="text-sm text-muted-foreground">
                  The goal is to make as much money as possible in 30 days. Buy drugs at low prices and sell them at
                  higher prices in different neighborhoods.
                </p>
              </div>

              <div className="bg-secondary/50 p-4 rounded-lg">
                <h3 className="font-medium flex items-center gap-2 mb-2">
                  <MapPin className="h-5 w-5 text-blue-500" />
                  Travel Between Areas
                </h3>
                <p className="text-sm text-muted-foreground">
                  Each neighborhood has different price levels. Travel between them to find the best deals, but be
                  careful - each trip advances the game by one day.
                </p>
              </div>

              <div className="bg-secondary/50 p-4 rounded-lg">
                <h3 className="font-medium flex items-center gap-2 mb-2">
                  <ShoppingBag className="h-5 w-5 text-purple-500" />
                  Manage Your Inventory
                </h3>
                <p className="text-sm text-muted-foreground">
                  Your trenchcoat has limited space. Use the bank to store your cash safely, and watch out for random
                  events that can help or hurt your business.
                </p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="about">
            <div className="space-y-4">
              <div className="bg-secondary/50 p-4 rounded-lg">
                <h3 className="font-medium flex items-center gap-2 mb-2">
                  <Info className="h-5 w-5 text-yellow-500" />
                  About This Game
                </h3>
                <p className="text-sm text-muted-foreground">
                  Dope Wars is a modern remake of the classic Drug Wars game from the 1980s. This version is built as a
                  Farcaster Frame game that you can play directly in your feed.
                </p>
              </div>

              <div className="bg-secondary/50 p-4 rounded-lg">
                <h3 className="font-medium flex items-center gap-2 mb-2">
                  <HelpCircle className="h-5 w-5 text-red-500" />
                  Disclaimer
                </h3>
                <p className="text-sm text-muted-foreground">
                  This game is purely fictional and for entertainment purposes only. It does not promote or endorse
                  illegal activities in any way.
                </p>
              </div>

              {/* Add the creator information here */}
              <div className="bg-secondary/50 p-4 rounded-lg">
                <h3 className="font-medium flex items-center gap-2 mb-2">
                  <User className="h-5 w-5 text-purple-500" />
                  Creator
                </h3>
                <p className="text-sm text-muted-foreground">
                  Made by thedude on Warpcast. DM for any bugs or feature requests.
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>

      <CardFooter className="border-t pt-6">
        <Button onClick={onContinue} className="w-full flex items-center justify-center gap-2" size="lg">
          Start Game
          <ArrowRight className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  )
}

