"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Minus, ShoppingBag, TrendingUp, TrendingDown } from "lucide-react"

interface MarketItem {
  id: string
  name: string
  price: number
  priceTrend: number
}

interface InventoryItem {
  id: string
  name: string
  quantity: number
  boughtAt: number
}

interface MarketViewProps {
  market: MarketItem[]
  cash: number
  inventory: InventoryItem[]
  maxInventory: number
  onBuy: (itemId: string) => void
  onSell: (itemId: string) => void
}

export default function MarketView({ market, cash, inventory, maxInventory, onBuy, onSell }: MarketViewProps) {
  // Calculate total inventory quantity
  const totalInventoryQuantity = inventory.reduce((acc, item) => acc + item.quantity, 0)
  const isInventoryFull = totalInventoryQuantity >= maxInventory

  return (
    <Card className="border shadow-sm">
      <CardHeader className="py-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <ShoppingBag className="h-5 w-5 text-primary" />
          Market Prices
        </CardTitle>
      </CardHeader>
      <CardContent className="pb-4">
        <div className="grid gap-2">
          {market.map((item) => {
            // Find if we have this item in inventory
            const inventoryItem = inventory.find((i) => i.id === item.id)
            const inventoryQuantity = inventoryItem?.quantity || 0
            const profitPerItem = inventoryItem ? item.price - inventoryItem.boughtAt : 0
            const profitClass =
              profitPerItem > 0 ? "text-green-500" : profitPerItem < 0 ? "text-red-500" : "text-gray-500"

            return (
              <div
                key={item.id}
                className="grid grid-cols-4 items-center p-2 rounded-md bg-secondary/50 hover:bg-secondary/70 transition-colors"
              >
                <div className="flex flex-col">
                  <span className="font-medium">{item.name}</span>
                  <div className="flex items-center text-sm text-muted-foreground">
                    {item.priceTrend > 0 ? (
                      <TrendingUp className="h-3 w-3 text-green-500 mr-1" />
                    ) : item.priceTrend < 0 ? (
                      <TrendingDown className="h-3 w-3 text-red-500 mr-1" />
                    ) : (
                      <Minus className="h-3 w-3 text-gray-500 mr-1" />
                    )}
                    <span>{Math.abs(item.priceTrend)}%</span>
                  </div>
                </div>

                <div className="text-right font-mono">${item.price}</div>

                <div className="text-right">
                  {inventoryQuantity > 0 && (
                    <div className="flex flex-col">
                      <span className="text-sm">Own: {inventoryQuantity}</span>
                      <span className={`text-xs ${profitClass}`}>
                        {profitPerItem > 0 ? "+" : ""}${profitPerItem}/unit
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex justify-end gap-1">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onBuy(item.id)}
                    disabled={cash < item.price || isInventoryFull}
                    title={
                      cash < item.price
                        ? "Not enough cash"
                        : isInventoryFull
                          ? "Inventory full"
                          : `Buy ${item.name} for $${item.price}`
                    }
                  >
                    Buy
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onSell(item.id)}
                    disabled={!inventoryQuantity}
                    title={
                      !inventoryQuantity
                        ? "None to sell"
                        : `Sell ${item.name} for $${item.price} (${
                            profitPerItem > 0 ? "+" : ""
                          }$${profitPerItem} profit)`
                    }
                  >
                    Sell
                  </Button>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}

