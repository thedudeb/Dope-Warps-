"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Trophy, Coins, TrendingUp, RotateCcw, ListOrdered } from "lucide-react"
import { addScore } from "@/lib/leaderboard"

export default function EndGameScreen({ gameState, onNewGame, onViewLeaderboard, fid, username }) {
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  // Calculate total assets
  const totalAssets = gameState.cash + gameState.bank - gameState.debt

  // Calculate inventory value
  const inventoryValue = gameState.inventory.reduce((total, item) => {
    const marketItem = gameState.currentLocation.market.find((m) => m.id === item.id)
    return total + (marketItem ? marketItem.price * item.quantity : 0)
  }, 0)

  // Calculate profit (total assets + inventory value - starting cash)
  const profit = totalAssets + inventoryValue - 2000 // Starting cash is 2000

  // Calculate score based on profit and days - UPDATED FOR 30 DAYS
  const score = Math.floor(profit * (30 / gameState.day))

  // Determine rank based on score
  let rank = "Street Hustler"
  if (score > 50000) rank = "Drug Kingpin"
  else if (score > 20000) rank = "Drug Lord"
  else if (score > 10000) rank = "Major Dealer"
  else if (score > 5000) rank = "Dealer"

  // Submit score to leaderboard
  const handleSubmitScore = async () => {
    if (!fid || submitted) return

    setSubmitting(true)

    try {
      const stats = {
        cash: gameState.cash,
        bank: gameState.bank,
        debt: gameState.debt,
        inventory: gameState.inventory.length,
        days: gameState.day,
        rank,
      }

      await addScore(fid, username, score, stats)
      setSubmitted(true)
    } catch (error) {
      console.error("Error submitting score:", error)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Card className="border-2 shadow-lg w-full max-w-2xl mx-auto">
      <CardHeader className="text-center border-b pb-6">
        <CardTitle className="text-3xl flex justify-center items-center gap-2">
          <Trophy className="h-8 w-8 text-yellow-500" />
          Game Over
        </CardTitle>
        <p className="text-xl font-bold mt-2">Your Final Rank: {rank}</p>
      </CardHeader>

      <CardContent className="pt-6 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-secondary/50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Coins className="h-5 w-5 text-green-500" />
              Final Assets
            </h3>
            <div className="mt-2 space-y-1">
              <div className="flex justify-between">
                <span>Cash:</span>
                <span className="font-mono">${gameState.cash.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Bank:</span>
                <span className="font-mono">${gameState.bank.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Debt:</span>
                <span className="font-mono text-red-500">-${gameState.debt.toLocaleString()}</span>
              </div>
              <div className="flex justify-between border-t pt-1 mt-1">
                <span>Total:</span>
                <span className="font-mono font-bold">${totalAssets.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="bg-secondary/50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-blue-500" />
              Performance
            </h3>
            <div className="mt-2 space-y-1">
              <div className="flex justify-between">
                <span>Days Played:</span>
                <span className="font-mono">{gameState.day}/30</span>
              </div>
              <div className="flex justify-between">
                <span>Inventory Value:</span>
                <span className="font-mono">${inventoryValue.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Profit:</span>
                <span className={`font-mono ${profit >= 0 ? "text-green-500" : "text-red-500"}`}>
                  ${profit.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between border-t pt-1 mt-1">
                <span>Final Score:</span>
                <span className="font-mono font-bold">{score.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-secondary/50 p-4 rounded-lg">
          <h3 className="text-lg font-semibold mb-2">Inventory Summary</h3>
          {gameState.inventory.length === 0 ? (
            <p className="text-muted-foreground">Your inventory is empty</p>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              {gameState.inventory.map((item) => (
                <div key={item.id} className="flex justify-between bg-background/50 p-2 rounded">
                  <span>{item.name}:</span>
                  <span className="font-mono">{item.quantity}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>

      <CardFooter className="border-t pt-6 flex flex-col gap-3">
        {fid && !submitted && (
          <Button
            onClick={handleSubmitScore}
            className="w-full flex items-center justify-center gap-2"
            disabled={submitting}
            variant="outline"
          >
            <Trophy className="h-4 w-4" />
            {submitting ? "Submitting..." : "Submit Score to Leaderboard"}
          </Button>
        )}

        {(submitted || !fid) && (
          <Button
            onClick={onViewLeaderboard}
            className="w-full flex items-center justify-center gap-2"
            variant="outline"
          >
            <ListOrdered className="h-4 w-4" />
            View Leaderboard
          </Button>
        )}

        <Button onClick={onNewGame} className="w-full flex items-center justify-center gap-2" size="lg">
          <RotateCcw className="h-4 w-4" />
          Start New Game
        </Button>
      </CardFooter>
    </Card>
  )
}

