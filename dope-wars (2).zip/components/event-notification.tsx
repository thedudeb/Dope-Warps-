"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle, CheckCircle, Info, X } from "lucide-react"
import { cn } from "@/lib/utils"

interface Event {
  id: number
  type: "positive" | "negative" | "neutral"
  title: string
  description: string
  additionalInfo?: string
}

interface EventNotificationProps {
  event: Event
  onAccept: () => void
  onDismiss: () => void
}

export default function EventNotification({ event, onAccept, onDismiss }: EventNotificationProps) {
  const [expanded, setExpanded] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  // Animation effect
  useEffect(() => {
    setIsVisible(true)

    // Auto-dismiss after 10 seconds
    const timer = setTimeout(() => {
      setIsVisible(false)
      setTimeout(onDismiss, 300) // Wait for fade out animation
    }, 10000)

    return () => clearTimeout(timer)
  }, [onDismiss])

  const getIcon = () => {
    switch (event.type) {
      case "positive":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "negative":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      case "neutral":
        return <Info className="h-5 w-5 text-blue-500" />
    }
  }

  const getColor = () => {
    switch (event.type) {
      case "positive":
        return "border-l-4 border-l-green-500"
      case "negative":
        return "border-l-4 border-l-red-500"
      case "neutral":
        return "border-l-4 border-l-blue-500"
    }
  }

  return (
    <Card
      className={cn(
        "shadow-lg transition-all duration-300 transform",
        getColor(),
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4",
      )}
      style={{
        maxWidth: "320px",
        backgroundColor: "rgba(17, 24, 39, 0.95)", // Darker background color
        backdropFilter: "blur(8px)",
      }}
    >
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-2">
            {getIcon()}
            <h3 className="font-medium">{event.title}</h3>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={() => {
              setIsVisible(false)
              setTimeout(onDismiss, 300)
            }}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </Button>
        </div>
        <p className="mt-2 text-sm">{event.description}</p>

        {event.additionalInfo && (
          <div className={cn("mt-2 overflow-hidden transition-all duration-300", expanded ? "max-h-24" : "max-h-0")}>
            <p className="text-sm text-muted-foreground">{event.additionalInfo}</p>
          </div>
        )}

        {event.additionalInfo && (
          <Button variant="ghost" size="sm" className="mt-1 h-6 px-2 text-xs" onClick={() => setExpanded(!expanded)}>
            {expanded ? "Show less" : "Show more"}
          </Button>
        )}
      </CardContent>

      <CardFooter className="p-2 pt-0 flex justify-end gap-2">
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            setIsVisible(false)
            setTimeout(onAccept, 300)
          }}
        >
          Accept
        </Button>
      </CardFooter>
    </Card>
  )
}

