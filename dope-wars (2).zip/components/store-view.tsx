"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Building2, Heart, AlertTriangle } from "lucide-react"

interface StoreViewProps {
  cash: number
  health: number
  onBuyHealth: (amount: number) => void
  onBuyItem: (itemId: string) => void
  deposit: (amount: number) => void
  withdraw: (amount: number) => void
  takeLoan: (amount: number) => void
  payDebt: (amount: number) => void
}

export default function StoreView({ cash, health, onBuyHealth, deposit, withdraw, takeLoan, payDebt }: StoreViewProps) {
  const [bankAmount, setBankAmount] = useState("")
  const [loanAmount, setLoanAmount] = useState("")

  const handleBuyHealth = () => {
    const healthNeeded = 100 - health
    if (healthNeeded <= 0) return

    // Calculate cost: $20 per health point
    const cost = healthNeeded * 20
    if (cash < cost) {
      // If not enough cash, buy as much as possible
      const affordableHealth = Math.floor(cash / 20)
      if (affordableHealth > 0) {
        onBuyHealth(affordableHealth)
      }
    } else {
      onBuyHealth(healthNeeded)
    }
  }

  const handleDeposit = () => {
    const amount = Number.parseInt(bankAmount)
    if (isNaN(amount) || amount <= 0 || amount > cash) return
    deposit(amount)
    setBankAmount("")
  }

  const handleWithdraw = () => {
    const amount = Number.parseInt(bankAmount)
    if (isNaN(amount) || amount <= 0) return
    withdraw(amount)
    setBankAmount("")
  }

  const handleTakeLoan = () => {
    const amount = Number.parseInt(loanAmount)
    if (isNaN(amount) || amount <= 0 || amount > 10000) return
    takeLoan(amount)
    setLoanAmount("")
  }

  const handlePayDebt = () => {
    const amount = Number.parseInt(loanAmount)
    if (isNaN(amount) || amount <= 0 || amount > cash) return
    payDebt(amount)
    setLoanAmount("")
  }

  return (
    <Card className="border shadow-sm">
      <CardHeader className="py-3">
        <CardTitle className="text-lg">Store & Services</CardTitle>
      </CardHeader>
      <CardContent className="pb-4">
        <Tabs defaultValue="health">
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="health">Health</TabsTrigger>
            <TabsTrigger value="bank">Bank</TabsTrigger>
          </TabsList>

          <TabsContent value="health">
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="flex items-center gap-1">
                    <Heart className="h-4 w-4 text-red-500" />
                    Health
                  </span>
                  <span>{health}%</span>
                </div>
                <Progress
                  value={health}
                  className="h-2"
                  indicatorClassName={health > 70 ? "bg-green-500" : health > 30 ? "bg-yellow-500" : "bg-red-500"}
                />
              </div>

              <div className="bg-secondary/50 p-3 rounded-lg">
                <h3 className="font-medium mb-2">Medical Services</h3>
                <p className="text-sm text-muted-foreground mb-3">Restore your health for $20 per health point.</p>
                <Button onClick={handleBuyHealth} disabled={health >= 100 || cash < 20} className="w-full">
                  {health >= 100 ? "Health Full" : `Heal to 100% (${100 - health} points, $${(100 - health) * 20})`}
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="bank">
            <div className="space-y-4">
              <div className="bg-secondary/50 p-3 rounded-lg">
                <h3 className="font-medium mb-2 flex items-center gap-1">
                  <Building2 className="h-4 w-4 text-blue-500" />
                  Banking Services
                </h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Deposit your cash to keep it safe from theft and muggings.
                </p>
                <div className="flex gap-2 mb-2">
                  <Input
                    type="number"
                    placeholder="Amount"
                    value={bankAmount}
                    onChange={(e) => setBankAmount(e.target.value)}
                    min={1}
                    max={cash}
                  />
                  <Button onClick={handleDeposit} disabled={!bankAmount || Number.parseInt(bankAmount) > cash}>
                    Deposit
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    placeholder="Amount"
                    value={bankAmount}
                    onChange={(e) => setBankAmount(e.target.value)}
                    min={1}
                  />
                  <Button onClick={handleWithdraw} disabled={!bankAmount}>
                    Withdraw
                  </Button>
                </div>
              </div>

              <div className="bg-secondary/50 p-3 rounded-lg">
                <h3 className="font-medium mb-2 flex items-center gap-1">
                  <AlertTriangle className="h-4 w-4 text-red-500" />
                  Loan Shark
                </h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Borrow money at 10% interest. Be careful, loan sharks don't like late payments.
                </p>
                <div className="flex gap-2 mb-2">
                  <Input
                    type="number"
                    placeholder="Amount"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                    min={100}
                    max={10000}
                  />
                  <Button onClick={handleTakeLoan} disabled={!loanAmount || Number.parseInt(loanAmount) > 10000}>
                    Borrow
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    placeholder="Amount"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                    min={1}
                    max={cash}
                  />
                  <Button onClick={handlePayDebt} disabled={!loanAmount || Number.parseInt(loanAmount) > cash}>
                    Repay
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

